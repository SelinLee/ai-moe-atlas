# mx1951-qwen

中文 / English / 日本語

## 来源 / Source / 出典
https://github.com/lmy414/ai-girl-stickers/issues/16
Revision: 03497f271d9cc3fa3628f70f98dd69786570e5cd

MX1951 — original-character — https://github.com/MX1951

## 使用条件 / Terms / 利用条件
CC0-1.0
MX1951 将本张立绘以 CC0 1.0 贡献至公共领域。图鉴记录作者及原始投稿，并保留原 PNG。相关产品名称和标识的权利由各权利方保留。
MX1951 dedicates this portrait to the public domain under CC0 1.0. The atlas credits the creator, links the submission and preserves the original PNG. Product names and marks retain their respective rights.
MX1951 はこの立ち絵に CC0 1.0 を指定。図鑑は作者名と原投稿を掲載し、元の PNG を保存。製品名・標章の権利は各権利者に帰属します。
Read the original terms and notices in evidence/; Bilibili sources include the creator’s permission statement and license link.

## 加工 / Processing / 加工内容
AI Moe Atlas only fits existing collected images to standard canvases and converts formats. Original bytes are preserved. No new character, pose, expression, or design was generated. 1024 px files may be resampled enlargements, not new image detail.
仅进行画布规范化、等比缩放和格式转换，保留原始字节。未生成新角色、新表情或新姿态。1024 像素文件可能为插值放大，并非新增细节。
既存の収集画像の余白・寸法・形式のみを統一しています。原本を保存し、新しいキャラクター・表情・ポーズは生成していません。1024 px 版は補間拡大の場合があり、細部の復元ではありません。

See manifest.json for source URLs, SHA-256, dimensions, transformations and permission evidence.
